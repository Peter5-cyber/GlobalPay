class ImageConstant {
  static String imgArrowdownBlack900 =
      'assets/images/img_arrowdown_black_900.svg';

  static String imgQrcode = 'assets/images/img_qrcode.svg';

  static String imgArrowdownBlueGray50 =
      'assets/images/img_arrowdown_blue_gray_50.svg';

  static String imgSearchGray5002 = 'assets/images/img_search_gray_500_2.svg';

  static String imgClockDeepPurple50 =
      'assets/images/img_clock_deep_purple_50.svg';

  static String imgMap011 = 'assets/images/img_map011.png';

  static String img1BlueGray400 = 'assets/images/img_1_blue_gray_400.svg';

  static String imgBanklogo = 'assets/images/img_banklogo.svg';

  static String imgFrame245 = 'assets/images/img_frame245.svg';

  static String imgIconWhiteA7001 = 'assets/images/img_icon_white_a700_1.svg';

  static String imgIcon40x40 = 'assets/images/img_icon_40x40.svg';

  static String imgGrid = 'assets/images/img_grid.svg';

  static String imgVectorIndigoA100 =
      'assets/images/img_vector_indigo_a100.svg';

  static String imgRefresh = 'assets/images/img_refresh.svg';

  static String imgVector = 'assets/images/img_vector.svg';

  static String imgGraph = 'assets/images/img_graph.svg';

  static String imgArrowdownIndigoA100 =
      'assets/images/img_arrowdown_indigo_a100.svg';

  static String imgIllustrationIndigoA100 =
      'assets/images/img_illustration_indigo_a100.svg';

  static String imgArrowdown = 'assets/images/img_arrowdown.svg';

  static String imgRectangle6650x50 = 'assets/images/img_rectangle66_50x50.png';

  static String imgArrowdownGray90001 =
      'assets/images/img_arrowdown_gray_900_01.svg';

  static String imgLinkedin = 'assets/images/img_linkedin.svg';

  static String imgClock15x15 = 'assets/images/img_clock_15x15.svg';

  static String imgMusic = 'assets/images/img_music.svg';

  static String imgLock = 'assets/images/img_lock.svg';

  static String imgRectangle6550x50 = 'assets/images/img_rectangle65_50x50.png';

  static String imgMenu = 'assets/images/img_menu.svg';

  static String imgIllustrationBlueGray800 =
      'assets/images/img_illustration_blue_gray_800.svg';

  static String imgCheckmark40x40 = 'assets/images/img_checkmark_40x40.svg';

  static String imgCheckmark1 = 'assets/images/img_checkmark_1.svg';

  static String imgClock = 'assets/images/img_clock.svg';

  static String imgUnitedstates = 'assets/images/img_unitedstates.png';

  static String imgEllipse31140x401 =
      'assets/images/img_ellipse311_40x40_1.png';

  static String imgQrcodeWhiteA700 = 'assets/images/img_qrcode_white_a700.svg';

  static String imgVideocamera = 'assets/images/img_videocamera.svg';

  static String imgAirplane = 'assets/images/img_airplane.svg';

  static String imgIllustrationBlueGray900212x212 =
      'assets/images/img_illustration_blue_gray_900_212x212.svg';

  static String imgRectangle6750x50 = 'assets/images/img_rectangle67_50x50.png';

  static String imgCloseBlack900 = 'assets/images/img_close_black_900.svg';

  static String imgElementGray300 = 'assets/images/img_element_gray_300.svg';

  static String imgVolume50x50 = 'assets/images/img_volume_50x50.svg';

  static String imgBrazil = 'assets/images/img_brazil.png';

  static String imgArrowright = 'assets/images/img_arrowright.svg';

  static String imgFrame244 = 'assets/images/img_frame244.svg';

  static String imgPlay30x30 = 'assets/images/img_play_30x30.svg';

  static String imgGroup199 = 'assets/images/img_group199.svg';

  static String imgEllipse31265x65 = 'assets/images/img_ellipse312_65x65.png';

  static String imgEllipse31065x65 = 'assets/images/img_ellipse310_65x65.png';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgMegaphone = 'assets/images/img_megaphone.svg';

  static String imgGlobe = 'assets/images/img_globe.svg';

  static String imgArrowdownGray500 =
      'assets/images/img_arrowdown_gray_500.svg';

  static String imgMore = 'assets/images/img_more.svg';

  static String imgArrowleftGray900 =
      'assets/images/img_arrowleft_gray_900.svg';

  static String imgFrame2261 = 'assets/images/img_frame2261.png';

  static String imgItaly = 'assets/images/img_italy.png';

  static String imgComputer23x36 = 'assets/images/img_computer_23x36.svg';

  static String imgSend = 'assets/images/img_send.svg';

  static String imgGroup = 'assets/images/img_group.svg';

  static String imgRectangle6450x50 = 'assets/images/img_rectangle64_50x50.png';

  static String imgIcon2 = 'assets/images/img_icon_2.png';

  static String imgSettings = 'assets/images/img_settings.svg';

  static String imgSearchBlack9001 = 'assets/images/img_search_black_900_1.svg';

  static String imgFloatingicon15x13 =
      'assets/images/img_floatingicon_15x13.svg';

  static String imgBookmark = 'assets/images/img_bookmark.svg';

  static String imgRectangle6350x50 = 'assets/images/img_rectangle63_50x50.png';

  static String imgFolder = 'assets/images/img_folder.svg';

  static String imgFire = 'assets/images/img_fire.svg';

  static String imgPortugal = 'assets/images/img_portugal.png';

  static String imgVectorRedA700 = 'assets/images/img_vector_red_a700.svg';

  static String imgComputerGray500 = 'assets/images/img_computer_gray_500.svg';

  static String imgIcon = 'assets/images/img_icon.svg';

  static String imgSignal = 'assets/images/img_signal.svg';

  static String imgRewind = 'assets/images/img_rewind.svg';

  static String imgSearchGray5001 = 'assets/images/img_search_gray_500_1.svg';

  static String imgVolume23x36 = 'assets/images/img_volume_23x36.svg';

  static String imgChat = 'assets/images/img_chat.svg';

  static String imgCheckmarkIndigoA100 =
      'assets/images/img_checkmark_indigo_a100.svg';

  static String imgCheckmarkGray500 =
      'assets/images/img_checkmark_gray_500.svg';

  static String imgArrowleftBlack900 =
      'assets/images/img_arrowleft_black_900.svg';

  static String imgElementGray20001 =
      'assets/images/img_element_gray_200_01.svg';

  static String imgNotification = 'assets/images/img_notification.svg';

  static String imgQrcodeWhiteA70050x50 =
      'assets/images/img_qrcode_white_a700_50x50.svg';

  static String imgUser1 = 'assets/images/img_user_1.svg';

  static String imgFloatingicon = 'assets/images/img_floatingicon.svg';

  static String imgPlus = 'assets/images/img_plus.svg';

  static String imgGoogleIndigoA100 =
      'assets/images/img_google_indigo_a100.svg';

  static String imgElementGray30015x234 =
      'assets/images/img_element_gray_300_15x234.svg';

  static String imgSearch = 'assets/images/img_search.svg';

  static String imgEllipse30950x50 = 'assets/images/img_ellipse309_50x50.png';

  static String imgVolumeBlack900 = 'assets/images/img_volume_black_900.svg';

  static String imgVectorIndigoA10015x210 =
      'assets/images/img_vector_indigo_a100_15x210.svg';

  static String imgSignal40x40 = 'assets/images/img_signal_40x40.svg';

  static String imgFile = 'assets/images/img_file.svg';

  static String imgEllipse31380x80 = 'assets/images/img_ellipse313_80x80.png';

  static String img1 = 'assets/images/img_1.svg';

  static String imgWhatsapp = 'assets/images/img_whatsapp.svg';

  static String imgCall = 'assets/images/img_call.svg';

  static String imgFacebook40x40 = 'assets/images/img_facebook_40x40.svg';

  static String imgCamera = 'assets/images/img_camera.svg';

  static String imgElementGray200 = 'assets/images/img_element_gray_200.svg';

  static String imgGroupGray200 = 'assets/images/img_group_gray_200.svg';

  static String imgCheckmark = 'assets/images/img_checkmark.svg';

  static String imgEllipse31150x50 = 'assets/images/img_ellipse311_50x50.png';

  static String imgIcon50x50 = 'assets/images/img_icon_50x50.png';

  static String imgIllustrationGray10001 =
      'assets/images/img_illustration_gray_100_01.svg';

  static String imgGermany = 'assets/images/img_germany.png';

  static String imgVectorRedA70023x198 =
      'assets/images/img_vector_red_a700_23x198.svg';

  static String imgEye = 'assets/images/img_eye.svg';

  static String imgUnitedkingdom = 'assets/images/img_unitedkingdom.png';

  static String imgDownload15x18 = 'assets/images/img_download_15x18.svg';

  static String imgClock25x25 = 'assets/images/img_clock_25x25.svg';

  static String imgUser40x40 = 'assets/images/img_user_40x40.svg';

  static String imgFrance = 'assets/images/img_france.png';

  static String imgEllipse31470x70 = 'assets/images/img_ellipse314_70x70.png';

  static String imgFrame242 = 'assets/images/img_frame242.svg';

  static String imgEllipse30840x40 = 'assets/images/img_ellipse308_40x40.png';

  static String imgFrame243 = 'assets/images/img_frame243.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
