import 'package:glblepay/core/app_export.dart';

class ApiClient extends GetConnect {}
