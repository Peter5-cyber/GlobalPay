class AtmLocationModel {}
