class CardSettingsModel {}
