class ConfirmationModel {}
