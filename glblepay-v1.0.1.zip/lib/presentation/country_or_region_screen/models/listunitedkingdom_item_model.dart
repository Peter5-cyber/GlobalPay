import 'package:get/get.dart';

class ListunitedkingdomItemModel {
  Rx<String> nameTxt = Rx("United Kingdom");

  Rx<String> radioGroup = Rx("");

  Rx<String>? id = Rx("");
}
