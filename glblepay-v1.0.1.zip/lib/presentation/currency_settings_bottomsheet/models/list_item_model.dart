import 'package:get/get.dart';

class ListItemModel {
  Rx<String> radioGroup = Rx("");

  Rx<String>? id = Rx("");
}
