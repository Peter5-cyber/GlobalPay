import 'package:get/get.dart';

class ListfireItemModel {
  Rx<String> storenameTxt = Rx("Apple Store");

  Rx<String> dateTxt = Rx("21 June, 2022");

  Rx<String> priceTxt = Rx("-220.00");

  Rx<String>? id = Rx("");
}
