import 'package:get/get.dart';

class ListvolumeItemModel {
  Rx<String> paymenttypeTxt = Rx("Behance");

  Rx<String> paymentmethodTxt = Rx("Credit Card");

  Rx<String>? id = Rx("");
}
