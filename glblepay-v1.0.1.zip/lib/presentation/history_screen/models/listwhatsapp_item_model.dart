import 'package:get/get.dart';

class ListwhatsappItemModel {
  Rx<String> productTxt = Rx("Skype Premium");

  Rx<String> priceTxt = Rx("-56.00");

  Rx<String> paymentmethodTxt = Rx("Debit Card");

  Rx<String>? id = Rx("");
}
