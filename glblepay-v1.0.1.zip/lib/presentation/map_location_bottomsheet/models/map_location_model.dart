class MapLocationModel {}
