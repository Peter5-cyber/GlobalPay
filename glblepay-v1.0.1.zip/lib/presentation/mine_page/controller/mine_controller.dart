import 'package:glblepay/core/app_export.dart';
import 'package:glblepay/presentation/mine_page/models/mine_model.dart';

class MineController extends GetxController {
  MineController(this.mineModelObj);

  Rx<MineModel> mineModelObj;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
