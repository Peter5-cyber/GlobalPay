import 'package:glblepay/core/app_export.dart';
import 'package:glblepay/presentation/mine_page_container_screen/models/mine_page_container_model.dart';
import 'package:glblepay/widgets/custom_bottom_app_bar.dart';

class MinePageContainerController extends GetxController {
  Rx<MinePageContainerModel> minePageContainerModelObj =
      MinePageContainerModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  @override
  void onInit() {}
}
