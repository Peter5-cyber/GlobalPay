class MinePageContainerModel {}
