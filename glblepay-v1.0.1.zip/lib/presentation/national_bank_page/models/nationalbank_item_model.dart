import 'package:get/get.dart';

class NationalbankItemModel {
  Rx<String> priceTxt = Rx("-220.00");

  Rx<String> timeTxt = Rx("10:30 PM, 18 June, 2022");

  Rx<String>? id = Rx("");
}
