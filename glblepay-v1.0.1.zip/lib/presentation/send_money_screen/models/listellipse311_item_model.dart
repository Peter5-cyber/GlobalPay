import 'package:get/get.dart';

class Listellipse311ItemModel {
  Rx<String> nameTxt = Rx("Alex Dordan");

  Rx<String> professionTxt = Rx("Web Developer");

  Rx<String>? id = Rx("");
}
