import 'package:get/get.dart';

class ListoneItemModel {
  Rx<String> oneTxt = Rx("1");

  Rx<String> twoTxt = Rx("2");

  Rx<String> threeTxt = Rx("3");

  Rx<String>? id = Rx("");
}
