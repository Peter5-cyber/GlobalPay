import 'package:get/get.dart';

class StatisticsItemModel {
  Rx<String> snapchatAdsTxt = Rx("Snapchat Ads");

  Rx<String> dateTxt = Rx("21 June, 2022");

  Rx<String> priceTxt = Rx("+130.00");

  Rx<String>? id = Rx("");
}
