class TransferAmountModel {}
