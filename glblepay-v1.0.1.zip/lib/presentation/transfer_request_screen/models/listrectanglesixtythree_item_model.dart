import 'package:get/get.dart';

class ListrectanglesixtythreeItemModel {
  Rx<String> nameTxt = Rx("Zander Wiza");

  Rx<String> professionTxt = Rx("UI/UX Designer");

  Rx<String>? id = Rx("");
}
