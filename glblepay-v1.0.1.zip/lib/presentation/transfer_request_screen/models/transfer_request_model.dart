import 'package:get/get.dart';
import 'listrectanglesixtythree_item_model.dart';

class TransferRequestModel {
  Rx<List<ListrectanglesixtythreeItemModel>> listrectanglesixtythreeItemList =
      Rx(List.generate(5, (index) => ListrectanglesixtythreeItemModel()));
}
