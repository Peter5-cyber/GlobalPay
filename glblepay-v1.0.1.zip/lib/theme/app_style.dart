import 'package:flutter/material.dart';
import 'package:glblepay/core/app_export.dart';

class AppStyle {
  static TextStyle txtPoppinsMedium10Gray500 = TextStyle(
    color: ColorConstant.gray500,
    fontSize: getFontSize(
      10,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsMedium8 = TextStyle(
    color: ColorConstant.gray500,
    fontSize: getFontSize(
      8,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsMedium9 = TextStyle(
    color: ColorConstant.gray500,
    fontSize: getFontSize(
      9,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsMedium15WhiteA700 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsMedium14Bluegray100 = TextStyle(
    color: ColorConstant.blueGray100,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsMedium13 = TextStyle(
    color: ColorConstant.indigoA100,
    fontSize: getFontSize(
      13,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsRegular10 = TextStyle(
    color: ColorConstant.gray500,
    fontSize: getFontSize(
      10,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtPoppinsMedium14 = TextStyle(
    color: ColorConstant.blueGray400,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsMedium11 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      11,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsMedium14WhiteA700 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsSemiBold16 = TextStyle(
    color: ColorConstant.indigoA100,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w600,
  );

  static TextStyle txtPoppinsMedium12 = TextStyle(
    color: ColorConstant.gray500,
    fontSize: getFontSize(
      12,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsMedium16Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsSemiBold16Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w600,
  );

  static TextStyle txtPoppinsSemiBold16Gray500 = TextStyle(
    color: ColorConstant.gray500,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w600,
  );

  static TextStyle txtPoppinsMedium10 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      10,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsMedium30 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      30,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsSemiBold18 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w600,
  );

  static TextStyle txtPoppinsMedium18 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtRobotoRegular20 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtPoppinsMedium15 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsMedium16 = TextStyle(
    color: ColorConstant.gray500,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsMedium12Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      12,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsMedium13Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      13,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsMedium9Bluegray400 = TextStyle(
    color: ColorConstant.blueGray400,
    fontSize: getFontSize(
      9,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsMedium14Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsMedium10Bluegray400 = TextStyle(
    color: ColorConstant.blueGray400,
    fontSize: getFontSize(
      10,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsMedium10Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      10,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsMedium16Bluegray400 = TextStyle(
    color: ColorConstant.blueGray400,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsMedium16WhiteA700 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtInterMedium11 = TextStyle(
    color: ColorConstant.gray500,
    fontSize: getFontSize(
      11,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsRegular14 = TextStyle(
    color: ColorConstant.blueGray400,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtPoppinsRegular16 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtProximaNovaABold28 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      28,
    ),
    fontFamily: 'Proxima Nova Alt',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtPoppinsSemiBold20 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w600,
  );

  static TextStyle txtPoppinsMedium20 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtRobotoRegular16 = TextStyle(
    color: ColorConstant.blueGray400,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtPoppinsRegular14IndigoA100 = TextStyle(
    color: ColorConstant.indigoA100,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtPoppinsMedium13WhiteA700 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      13,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsMedium11Gray500 = TextStyle(
    color: ColorConstant.gray500,
    fontSize: getFontSize(
      11,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsMedium11Bluegray400 = TextStyle(
    color: ColorConstant.blueGray400,
    fontSize: getFontSize(
      11,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsMedium15Gray500 = TextStyle(
    color: ColorConstant.gray500,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtPoppinsMedium14Gray500 = TextStyle(
    color: ColorConstant.gray500,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );
}
